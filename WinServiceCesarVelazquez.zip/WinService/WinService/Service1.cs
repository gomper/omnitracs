﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Timers;
using System.Threading.Tasks;
using System.IO;
using System.Net.Http;
using System.CodeDom;
using Newtonsoft.Json;

namespace WinService
{
    public partial class Service1 : ServiceBase
    {
        Timer timer = new Timer();

        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {

            //WriteToFile("Service is started at " + DateTime.Now);
            timer.Elapsed += new ElapsedEventHandler(OnElapsedTime);
            timer.Interval = 2000; 
            timer.Enabled = true;
        }

        protected override void OnStop()
        {
            //WriteToFile("Service is stopped at " + DateTime.Now);
        }

        public void WriteToFile(string message)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory;
            string filepath = string.Format("{0}ServiceLog_{1}.csv", AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.Date.ToShortDateString().Replace('/', '_'));

            if (!File.Exists(filepath))
            {
                using (StreamWriter sw = File.CreateText(filepath))
                {
                    sw.WriteLine(message);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    sw.WriteLine(message);
                }
            }
        }

        private void OnElapsedTime(object source, ElapsedEventArgs e)
        {
            //WriteToFile("Service is recall at " + DateTime.Now);

            Task<Weather> t = Task.Run<Weather>(async () => await GetWeather());
            Weather w = t.Result;
            // s eusa humedad en lugar de pricipitacióm.
            WriteToFile(string.Format("{0},{1},{2},{3}", w.main.temp, w.Units, w.main.humidity, DateTime.Now.ToString("dd-MMMM-yyyy HH:mm:ss")));

        }

        async Task<Weather> GetWeather()
        {
            string c = string.Empty;
            HttpClient client = new HttpClient();
            
            // free weather
            Uri uri = new Uri("https://api.openweathermap.org/data/2.5/weather?id=4684888&units=metric&appid=9965a9eab12daa0edf8b899a617e6b92");
            HttpResponseMessage rm = await client.GetAsync(uri);
            Weather w = new Weather();

            if(rm.IsSuccessStatusCode)
            {
                 c = await rm.Content.ReadAsStringAsync();
                //WriteToFile(string.Format("Full Weather {0}", c));
            }

            w = JsonConvert.DeserializeObject<Weather>(c);
            w.Units = "Celsius";
           
            return w;
        }
    }

    public class Weather
    {
        public WMain main { get; set; }
        public string Units { get; set; }
        public string rain { get; set; }
        
    }

    public class WMain
    {
        public string temp { get; set; }
        public string temp_min { get; set; }
        public string humidity { get; set; }

    }
}
